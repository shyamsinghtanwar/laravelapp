<!--  Breadcrumb Area Start  -->
<div class="breadcrumb-area breadcrumb-bg">
    <div class="container">
        <div class="row">
            <div class="col-lg-12 text-center">
                <div class="breadcrumb-txt">
                    <h1>{{$page_title}}</h1>
                </div>
            </div>
        </div>

    </div>
    <div class="breadcrumb-overlay"></div>
</div>
<!--  Breadcrumb Area End  -->
